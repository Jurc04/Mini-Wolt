﻿namespace SeminarskaNalogaIzdelek
{
    partial class GlavniMeniAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            Dodaj = new Button();
            label1 = new Label();
            textBox1 = new TextBox();
            listBox1 = new ListBox();
            Uporabnik = new Button();
            Potrdi = new Button();
            Odstrani = new Button();
            Odjava = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 4;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45.7142868F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54.2857132F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 289F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 230F));
            tableLayoutPanel1.Controls.Add(Dodaj, 0, 2);
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Controls.Add(textBox1, 2, 1);
            tableLayoutPanel1.Controls.Add(listBox1, 0, 1);
            tableLayoutPanel1.Controls.Add(Potrdi, 3, 3);
            tableLayoutPanel1.Controls.Add(Odstrani, 1, 2);
            tableLayoutPanel1.Controls.Add(Odjava, 2, 3);
            tableLayoutPanel1.Controls.Add(Uporabnik, 2, 2);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 10.810811F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 89.1891861F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 104F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 66F));
            tableLayoutPanel1.Size = new Size(800, 450);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // Dodaj
            // 
            Dodaj.Location = new Point(3, 282);
            Dodaj.Name = "Dodaj";
            Dodaj.Size = new Size(75, 23);
            Dodaj.TabIndex = 0;
            Dodaj.Text = "Dodaj";
            Dodaj.UseVisualStyleBackColor = true;
            Dodaj.Click += Dodaj_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(label1, 4);
            label1.Location = new Point(3, 7);
            label1.Name = "label1";
            label1.Size = new Size(794, 15);
            label1.TabIndex = 2;
            label1.Text = "Pozdravljen, tukaj v administratorskem načinu lahko dodajaš in brišeš restavracije ter dodajaš ponudbe.";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // textBox1
            // 
            tableLayoutPanel1.SetColumnSpan(textBox1, 2);
            textBox1.Location = new Point(283, 33);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(514, 242);
            textBox1.TabIndex = 3;
            // 
            // listBox1
            // 
            tableLayoutPanel1.SetColumnSpan(listBox1, 2);
            listBox1.Dock = DockStyle.Fill;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(3, 33);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(274, 243);
            listBox1.TabIndex = 4;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // Uporabnik
            // 
            Uporabnik.Location = new Point(283, 282);
            Uporabnik.Name = "Uporabnik";
            Uporabnik.Size = new Size(75, 23);
            Uporabnik.TabIndex = 6;
            Uporabnik.Text = "Uporabnik";
            Uporabnik.UseVisualStyleBackColor = true;
            Uporabnik.Click += Uporabnik_Click;
            // 
            // Potrdi
            // 
            Potrdi.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            Potrdi.Location = new Point(722, 424);
            Potrdi.Name = "Potrdi";
            Potrdi.Size = new Size(75, 23);
            Potrdi.TabIndex = 7;
            Potrdi.Text = "Potrdi";
            Potrdi.UseVisualStyleBackColor = true;
            Potrdi.Click += Potrdi_Click;
            // 
            // Odstrani
            // 
            Odstrani.Location = new Point(131, 282);
            Odstrani.Name = "Odstrani";
            Odstrani.Size = new Size(75, 23);
            Odstrani.TabIndex = 1;
            Odstrani.Text = "Odstrani";
            Odstrani.UseVisualStyleBackColor = true;
            Odstrani.Click += Odstrani_Click;
            // 
            // Odjava
            // 
            Odjava.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            Odjava.Location = new Point(491, 424);
            Odjava.Name = "Odjava";
            Odjava.Size = new Size(75, 23);
            Odjava.TabIndex = 8;
            Odjava.Text = "Odjava";
            Odjava.UseVisualStyleBackColor = true;
            Odjava.Click += Odjava_Click;
            // 
            // GlavniMeniAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tableLayoutPanel1);
            Name = "GlavniMeniAdmin";
            Text = "GlavniMeniAdmin";
            Load += GlavniMeniAdmin_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Button Dodaj;
        private Button Odstrani;
        private Label label1;
        private TextBox textBox1;
        private ListBox listBox1;
        private Button Uporabnik;
        private Button Potrdi;
        private Button Odjava;
    }
}