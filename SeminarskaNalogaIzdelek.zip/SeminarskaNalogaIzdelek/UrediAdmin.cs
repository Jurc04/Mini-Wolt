﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeminarskaNalogaIzdelek
{
    public partial class UrediAdmin : Form
    {
        private int UporabnikId;

        public UrediAdmin(int id, string UporabnikIme)
        {
            InitializeComponent();

            listBox1.Items.Clear();
            listBox1.Items.Add(UporabnikIme);
            listBox1.SelectedIndex = 0;
            UporabnikId = id;

        }

        private void Nazaj_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Uporabnik = new UporabnikAdmin();
            Uporabnik.Show();
        }

        private void Shrani_Click(object sender, EventArgs e)
        {
            string SpremeniIme = textBox1.Text.Trim();

            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open();
                var ukaz = connection.CreateCommand();
                ukaz.CommandText = "UPDATE uporabnik SET ime = @ime WHERE id = @id";
                ukaz.Parameters.AddWithValue("@ime", SpremeniIme);
                ukaz.Parameters.AddWithValue("@id", UporabnikId);
                ukaz.ExecuteNonQuery();
            }
            MessageBox.Show("Uporabnik je posodobljen");

        }
    }
}
