﻿namespace SeminarskaNalogaIzdelek
{
    partial class GlavniMeni
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            label1 = new Label();
            label2 = new Label();
            listBox1 = new ListBox();
            listBox2 = new ListBox();
            Naprej = new Button();
            Odjava = new Button();
            DodajArtikel = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 49F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 51F));
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Controls.Add(label2, 1, 0);
            tableLayoutPanel1.Controls.Add(listBox1, 0, 1);
            tableLayoutPanel1.Controls.Add(listBox2, 1, 1);
            tableLayoutPanel1.Controls.Add(Naprej, 1, 3);
            tableLayoutPanel1.Controls.Add(Odjava, 0, 3);
            tableLayoutPanel1.Controls.Add(DodajArtikel, 1, 2);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 14.7286825F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 85.27132F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 106F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 50F));
            tableLayoutPanel1.Size = new Size(800, 450);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Location = new Point(3, 14);
            label1.Name = "label1";
            label1.Size = new Size(386, 15);
            label1.TabIndex = 0;
            label1.Text = "Izberi restavracijo:";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Location = new Point(395, 14);
            label2.Name = "label2";
            label2.Size = new Size(402, 15);
            label2.TabIndex = 1;
            label2.Text = "Ponudba od izbrane restavracije:";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // listBox1
            // 
            listBox1.Dock = DockStyle.Fill;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(3, 46);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(386, 244);
            listBox1.TabIndex = 2;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // listBox2
            // 
            listBox2.Dock = DockStyle.Fill;
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(395, 46);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(402, 244);
            listBox2.TabIndex = 3;
            // 
            // Naprej
            // 
            Naprej.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            Naprej.Location = new Point(714, 424);
            Naprej.Name = "Naprej";
            Naprej.Size = new Size(83, 23);
            Naprej.TabIndex = 4;
            Naprej.Text = "Naprej";
            Naprej.UseVisualStyleBackColor = true;
            Naprej.Click += Naprej_Click;
            // 
            // Odjava
            // 
            Odjava.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            Odjava.Location = new Point(3, 424);
            Odjava.Name = "Odjava";
            Odjava.Size = new Size(75, 23);
            Odjava.TabIndex = 5;
            Odjava.Text = "Odjava";
            Odjava.UseVisualStyleBackColor = true;
            Odjava.Click += Odjava_Click;
            // 
            // DodajArtikel
            // 
            DodajArtikel.Location = new Point(395, 296);
            DodajArtikel.Name = "DodajArtikel";
            DodajArtikel.Size = new Size(90, 23);
            DodajArtikel.TabIndex = 6;
            DodajArtikel.Text = "Dodaj artikel";
            DodajArtikel.UseVisualStyleBackColor = true;
            DodajArtikel.Click += DodajArtikel_Click;
            // 
            // GlavniMeni
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tableLayoutPanel1);
            Name = "GlavniMeni";
            Text = "GlavniMeni";
            Load += GlavniMeni_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private Label label2;
        private ListBox listBox1;
        private ListBox listBox2;
        private Button Naprej;
        private Button Odjava;
        private Button DodajArtikel;
    }
}