﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace SeminarskaNalogaIzdelek
{
    public partial class Prijava : Form
    {
        public Prijava()
        {
            InitializeComponent();
        }



        private void PrijaviSe_Click(object sender, EventArgs e)
        {
            string ImePrijava = textBox1.Text.Trim();
            string GesloPrijava = textBox2.Text.Trim();

            if (ImePrijava == "admin" && GesloPrijava == "administrator")
            {
                this.Hide();
                var GlavniAdmin = new GlavniMeniAdmin();
                GlavniAdmin.Show();
                return;
            }

            if (string.IsNullOrEmpty(ImePrijava) || string.IsNullOrEmpty(GesloPrijava))
            {
                MessageBox.Show("Vnesi uporabniško ime in geslo.");
                return;
            }

            string hash = hashGeslo(GesloPrijava);

            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open(); // odpremo povezavo
                var ukaz = connection.CreateCommand(); // kreiramo ukaz
                ukaz.CommandText = "SELECT COUNT(*) FROM uporabnik WHERE ime = @Ime AND geslo = @Geslo";
                ukaz.Parameters.AddWithValue("@Ime", ImePrijava);
                ukaz.Parameters.AddWithValue("@Geslo", hash);

                long StZadetkov = (long)ukaz.ExecuteScalar();

                if (StZadetkov > 0)
                {
                    this.Hide();
                    var mainForm = new GlavniMeni();
                    mainForm.Show();
                }
                else
                {
                    MessageBox.Show("Napačno uporabniško ime ali geslo.");
                }
            }
        }
        private string hashGeslo(string geslo)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(geslo));
                StringBuilder builder = new StringBuilder();
                foreach (var b in bytes)
                    builder.Append(b.ToString("x2"));
                return builder.ToString();
            }
        }

        private void Registracija_Click(object sender, EventArgs e)
        {
            this.Hide();
            var stran = new Registracija();
            stran.Show();
        }
    }
}
