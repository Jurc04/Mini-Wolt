using Microsoft.Data.Sqlite;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Text;


namespace SeminarskaNalogaIzdelek
{
    public partial class Registracija : Form
    {
        public Registracija()
        {
            InitializeComponent();
        }

        private void RegistrirajSe_Click(object sender, EventArgs e)
        {
            string ImeBaza = textBox1.Text.Trim();
            string GesloBaza = textBox2.Text.Trim();

            if (string.IsNullOrEmpty(ImeBaza) || string.IsNullOrEmpty(GesloBaza))
            {
                MessageBox.Show("Vnesi uporabni�ko ime in geslo.");
                return;
            }

            string hash = hashGeslo(GesloBaza);


            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open(); // odpremo povezavo
                var ukaz = connection.CreateCommand(); // kreiramo ukaz
                ukaz.CommandText = "INSERT INTO uporabnik (ime, geslo) VALUES (@Ime, @Geslo)";
                ukaz.Parameters.AddWithValue("@Ime", ImeBaza);
                ukaz.Parameters.AddWithValue("@Geslo", hash);
                ukaz.ExecuteNonQuery();
            }
            this.Hide();
            var PrijavaForma = new Prijava();
            PrijavaForma.Show();
        }

        private string hashGeslo(string geslo)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(geslo));
                StringBuilder builder = new StringBuilder();
                foreach (var b in bytes)
                    builder.Append(b.ToString("x2"));
                return builder.ToString();
            }
        }

        private void Prijava_Click(object sender, EventArgs e)
        {
            this.Hide();
            var PrijavaForma = new Prijava();
            PrijavaForma.Show();

        }
    }
}
