﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeminarskaNalogaIzdelek
{
    public partial class DodajAdmin : Form
    {
        public DodajAdmin()
        {
            InitializeComponent();
        }

        private void Nazaj_Click(object sender, EventArgs e)
        {
            this.Hide();
            var GlavniMeni = new GlavniMeniAdmin();
            GlavniMeni.Show();
        }

        private void Potrdi_Click(object sender, EventArgs e)
        {
            string naziv = textBox1.Text;

            if (string.IsNullOrEmpty(naziv))
            {
                MessageBox.Show("Prosim vnesi naziv");
                textBox1.Clear();
                return;
            }
            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open();

                var ukaz = connection.CreateCommand();
                ukaz.CommandText = "INSERT INTO restavracija (naziv) VALUES (@naziv)";

                ukaz.Parameters.AddWithValue("@naziv", naziv);

                ukaz.ExecuteNonQuery();

                MessageBox.Show("Naziv uspešno dodan v bazo!");
            }
        }
    }
}
