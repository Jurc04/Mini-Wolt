﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeminarskaNalogaIzdelek
{
    public partial class GlavniMeni : Form
    {
        public GlavniMeni()
        {
            InitializeComponent();
        }

        private void GlavniMeni_Load(object sender, EventArgs e)
        {
            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open(); // odpremo povezavo
                var ukaz = connection.CreateCommand(); // kreiramo ukaz
                ukaz.CommandText = "SELECT DISTINCT naziv FROM restavracija"; // nastavimo poizvedbo
                var reader = ukaz.ExecuteReader(); // "bralec" podatkov - bere po vrsticah
                while (reader.Read()) // dokler je branje uspešno (smo imeli kaj za prebrati)
                {
                    string Naziv = reader.GetString(0);
                    listBox1.Items.Add(Naziv);
                }
            }
        }

        private void DodajArtikel_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1 || listBox2.SelectedIndex == -1)
            {
                MessageBox.Show("Izberi restavracijo in jed.");
                return;
            }

            string restavracija = listBox1.SelectedItem.ToString();
            string JedCena = listBox2.SelectedItem.ToString();

            string jed = JedCena.Split('(')[0].Trim();
            string cena = JedCena.Split('(')[1].Replace(")", "").Trim();

            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open();
                var ukaz = connection.CreateCommand();
                ukaz.CommandText = "INSERT INTO naročilo (restavracija, jed, cena) VALUES (@restavracija, @jed, @cena)";
                ukaz.Parameters.AddWithValue("@restavracija", restavracija);
                ukaz.Parameters.AddWithValue("@jed", jed);
                ukaz.Parameters.AddWithValue("@cena", cena);
                ukaz.ExecuteNonQuery();
            }
        }

        private void Odjava_Click(object sender, EventArgs e)
        {
            this.Hide();
            var prijava = new Prijava();
            prijava.Show();
        }

        private void Naprej_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Narocilo = new Narocilo();
            Narocilo.Show();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();

            if (listBox1.SelectedItem != null)
            {
                string IzbraniNaziv = listBox1.SelectedItem.ToString();

                using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
                {
                    connection.Open();
                    var ukaz = connection.CreateCommand();
                    ukaz.CommandText = "SELECT jedi FROM restavracija WHERE naziv = @naziv";
                    ukaz.Parameters.AddWithValue("@naziv", IzbraniNaziv);
                    var reader = ukaz.ExecuteReader();

                    if (reader.Read())
                    {
                        string jediRaw = reader.GetString(0);

                        var jediList = jediRaw.Split('#');

                        foreach (var zapis in jediList)
                        {
                            var deli = zapis.Split('|');
                            if (deli.Length == 2)
                            {
                                string nazivJed = deli[0].Trim();
                                string cena = deli[1].Trim();
                                listBox2.Items.Add($"{nazivJed} ({cena})");
                            }
                        }
                    }
                }
            }
        }
    }
}
