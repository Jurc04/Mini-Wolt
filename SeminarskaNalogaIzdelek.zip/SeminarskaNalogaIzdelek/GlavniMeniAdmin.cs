﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeminarskaNalogaIzdelek
{
    public partial class GlavniMeniAdmin : Form
    {
        public GlavniMeniAdmin()
        {
            InitializeComponent();
        }

        private void GlavniMeniAdmin_Load(object sender, EventArgs e)
        {
            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open(); // odpremo povezavo
                var ukaz = connection.CreateCommand(); // kreiramo ukaz
                ukaz.CommandText = "SELECT * FROM restavracija"; // nastavimo poizvedbo
                var reader = ukaz.ExecuteReader(); // "bralec" podatkov - bere po vrsticah
                while (reader.Read()) // dokler je branje uspešno (smo imeli kaj za prebrati)
                {
                    listBox1.Items.Add(reader.GetString(reader.GetOrdinal("naziv"))); // dobimo 2. stolpec (index 1) kot string - to je stolpec z imenom stranke
                }
            }
        }



        private string DobiVsebino(string naziv)
        {
            string jedi = "";

            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open();
                var ukaz = connection.CreateCommand();
                ukaz.CommandText = "SELECT jedi FROM restavracija WHERE naziv = @naziv";
                ukaz.Parameters.AddWithValue("@naziv", naziv);

                using (var reader = ukaz.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        if (!reader.IsDBNull(reader.GetOrdinal("jedi")))
                        {
                            jedi = reader.GetString(reader.GetOrdinal("jedi"));
                        }
                    }
                }
            }

            if (!string.IsNullOrEmpty(jedi))
            {
                var elementi = jedi.Split('#');
                var rezultat = elementi
                    .Select(e =>
                    {
                        var deli = e.Split('|');
                        return deli.Length == 2 ? $"{deli[0]} {deli[1]}" : e;
                    });

                return string.Join(Environment.NewLine, rezultat);
            }

            return "";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                string naziv = listBox1.SelectedItem.ToString();
                textBox1.Text = DobiVsebino(naziv);
            }
        }

        private void Odjava_Click(object sender, EventArgs e)
        {
            this.Hide();
            var prijava = new Prijava();
            prijava.Show();
        }

        private void Odstrani_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                string naziv = listBox1.SelectedItem.ToString();
                using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
                {
                    connection.Open(); // odpremo povezavo
                    var ukaz = connection.CreateCommand(); // kreiramo ukaz
                    ukaz.CommandText = "DELETE FROM restavracija WHERE naziv = @naziv"; // nastavimo poizvedbo
                    ukaz.Parameters.AddWithValue("@naziv", naziv);

                    int vrstice = ukaz.ExecuteNonQuery();

                    if (vrstice > 0)
                    {
                        MessageBox.Show($"Stran {naziv} je bila uspešno odstranjena!", "Uspešno", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        listBox1.Items.Remove(naziv);
                    }
                    else
                    {
                        MessageBox.Show($"Stran {naziv} ni bila odstranjena, saj ne obstaja.", "Napaka", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void Dodaj_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Dodaj = new DodajAdmin();
            Dodaj.Show();
        }

        private void Uporabnik_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Uporabnik = new UporabnikAdmin();
            Uporabnik.Show();
        }

        private void Potrdi_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                string naziv = listBox1.SelectedItem.ToString();
                string vsebina = textBox1.Text.Trim();

                // razdeli po vrsticah
                var vrstice = vsebina.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                List<string> zapisaneJedi = new List<string>();

                foreach (var vrstica in vrstice)
                {
                    var deli = vrstica.Trim().Split(' ');

                    if (deli.Length >= 2)
                    {
                        string cena = deli.Last();
                        string jed = string.Join(" ", deli.Take(deli.Length - 1));
                        zapisaneJedi.Add($"{jed}|{cena}");
                    }
                }

                string zapisVBazo = string.Join("#", zapisaneJedi);

                using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
                {
                    connection.Open();
                    var ukaz = connection.CreateCommand();
                    ukaz.CommandText = "UPDATE restavracija SET jedi = @jedi WHERE naziv = @naziv";
                    ukaz.Parameters.AddWithValue("@jedi", zapisVBazo);
                    ukaz.Parameters.AddWithValue("@naziv", naziv);
                    ukaz.ExecuteNonQuery();
                }

                MessageBox.Show("Uspešno shranjeno.");
            }
        }
    }
}
