﻿namespace SeminarskaNalogaIzdelek
{
    partial class DodajUporabnikaAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            label1 = new Label();
            textBox1 = new TextBox();
            label2 = new Label();
            textBox2 = new TextBox();
            Potrdi = new Button();
            Nazaj = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(label1, 0, 1);
            tableLayoutPanel1.Controls.Add(textBox1, 1, 1);
            tableLayoutPanel1.Controls.Add(label2, 0, 2);
            tableLayoutPanel1.Controls.Add(textBox2, 1, 2);
            tableLayoutPanel1.Controls.Add(Potrdi, 1, 3);
            tableLayoutPanel1.Controls.Add(Nazaj, 0, 3);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 65.11628F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 34.88372F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 47F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 253F));
            tableLayoutPanel1.Size = new Size(800, 450);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Location = new Point(3, 115);
            label1.Name = "label1";
            label1.Size = new Size(394, 15);
            label1.TabIndex = 0;
            label1.Text = "Vpiši ime uporabnika:";
            label1.TextAlign = ContentAlignment.TopRight;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            textBox1.Location = new Point(403, 111);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(394, 23);
            textBox1.TabIndex = 1;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Location = new Point(3, 165);
            label2.Name = "label2";
            label2.Size = new Size(394, 15);
            label2.TabIndex = 2;
            label2.Text = "Nastavi še geslo:";
            label2.TextAlign = ContentAlignment.TopRight;
            // 
            // textBox2
            // 
            textBox2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            textBox2.Location = new Point(403, 161);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(394, 23);
            textBox2.TabIndex = 3;
            textBox2.UseSystemPasswordChar = true;
            // 
            // Potrdi
            // 
            Potrdi.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            Potrdi.Location = new Point(722, 424);
            Potrdi.Name = "Potrdi";
            Potrdi.Size = new Size(75, 23);
            Potrdi.TabIndex = 4;
            Potrdi.Text = "Potrdi";
            Potrdi.UseVisualStyleBackColor = true;
            Potrdi.Click += Potrdi_Click;
            // 
            // Nazaj
            // 
            Nazaj.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            Nazaj.Location = new Point(3, 424);
            Nazaj.Name = "Nazaj";
            Nazaj.Size = new Size(75, 23);
            Nazaj.TabIndex = 5;
            Nazaj.Text = "Nazaj";
            Nazaj.UseVisualStyleBackColor = true;
            Nazaj.Click += Nazaj_Click;
            // 
            // DodajUporabnikaAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tableLayoutPanel1);
            Name = "DodajUporabnikaAdmin";
            Text = "DodajUporabnikaAdmin";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private TextBox textBox2;
        private Button Potrdi;
        private Button Nazaj;
    }
}