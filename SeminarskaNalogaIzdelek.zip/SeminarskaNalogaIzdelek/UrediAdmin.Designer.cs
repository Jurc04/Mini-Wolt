﻿namespace SeminarskaNalogaIzdelek
{
    partial class UrediAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            label1 = new Label();
            label2 = new Label();
            Shrani = new Button();
            Nazaj = new Button();
            listBox1 = new ListBox();
            label3 = new Label();
            textBox1 = new TextBox();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Controls.Add(label2, 0, 1);
            tableLayoutPanel1.Controls.Add(Shrani, 1, 5);
            tableLayoutPanel1.Controls.Add(Nazaj, 0, 5);
            tableLayoutPanel1.Controls.Add(listBox1, 1, 1);
            tableLayoutPanel1.Controls.Add(label3, 0, 2);
            tableLayoutPanel1.Controls.Add(textBox1, 1, 2);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 6;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 43.5483856F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 56.4516144F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 54F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 80F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 178F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 57F));
            tableLayoutPanel1.Size = new Size(800, 450);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(label1, 2);
            label1.Location = new Point(3, 10);
            label1.Name = "label1";
            label1.Size = new Size(794, 15);
            label1.TabIndex = 0;
            label1.Text = "Tukaj urediš uporabnika";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Location = new Point(3, 50);
            label2.Name = "label2";
            label2.Size = new Size(394, 15);
            label2.TabIndex = 1;
            label2.Text = "Uporabnik katerega trenutno urejaš je:";
            label2.TextAlign = ContentAlignment.TopRight;
            // 
            // Shrani
            // 
            Shrani.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            Shrani.Location = new Point(722, 424);
            Shrani.Name = "Shrani";
            Shrani.Size = new Size(75, 23);
            Shrani.TabIndex = 2;
            Shrani.Text = "Shrani";
            Shrani.UseVisualStyleBackColor = true;
            Shrani.Click += Shrani_Click;
            // 
            // Nazaj
            // 
            Nazaj.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            Nazaj.Location = new Point(3, 424);
            Nazaj.Name = "Nazaj";
            Nazaj.Size = new Size(75, 23);
            Nazaj.TabIndex = 3;
            Nazaj.Text = "Nazaj";
            Nazaj.UseVisualStyleBackColor = true;
            Nazaj.Click += Nazaj_Click;
            // 
            // listBox1
            // 
            listBox1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(403, 48);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(394, 19);
            listBox1.TabIndex = 4;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label3.AutoSize = true;
            label3.Location = new Point(3, 99);
            label3.Name = "label3";
            label3.Size = new Size(394, 15);
            label3.TabIndex = 5;
            label3.Text = "Spremeni ime:";
            label3.TextAlign = ContentAlignment.TopRight;
            // 
            // textBox1
            // 
            textBox1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            textBox1.Location = new Point(403, 95);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(394, 23);
            textBox1.TabIndex = 6;
            // 
            // UrediAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tableLayoutPanel1);
            Name = "UrediAdmin";
            Text = "UrediAdmin";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private Label label2;
        private Button Shrani;
        private Button Nazaj;
        private ListBox listBox1;
        private Label label3;
        private TextBox textBox1;
    }
}