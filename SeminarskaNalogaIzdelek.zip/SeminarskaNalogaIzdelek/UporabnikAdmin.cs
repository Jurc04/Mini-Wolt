﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeminarskaNalogaIzdelek
{
    public partial class UporabnikAdmin : Form
    {
        public UporabnikAdmin()
        {
            InitializeComponent();
        }

        private void UporabnikAdmin_Load(object sender, EventArgs e)
        {
            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open();
                var ukaz = connection.CreateCommand();
                ukaz.CommandText = "SELECT id, ime FROM uporabnik";

                using (var reader = ukaz.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var user = new KeyValuePair<int, string>(reader.GetInt32(0), reader.GetString(1));
                        listBox1.Items.Add(user);
                    }
                }
            }
        }

        private void Uredi_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem is KeyValuePair<int, string> izbranUporabnik)
            {
                int id = izbranUporabnik.Key;
                string ime = izbranUporabnik.Value;

                var urediForm = new UrediAdmin(id, ime);
                urediForm.ShowDialog();
            }
        }

        private void Nazaj_Click(object sender, EventArgs e)
        {
            this.Hide();
            var GlavniMeni = new GlavniMeniAdmin();
            GlavniMeni.Show();
        }

        private void Izbrisi_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem is KeyValuePair<int, string> izbranUporabnik)
            {
                int id = izbranUporabnik.Key;
                string ime = izbranUporabnik.Value;

                using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
                {
                    connection.Open();
                    var ukaz = connection.CreateCommand();
                    ukaz.CommandText = "DELETE FROM Uporabnik WHERE id = @id AND ime = @ime";

                    ukaz.Parameters.AddWithValue("@id", id);
                    ukaz.Parameters.AddWithValue("@ime", ime);
                    ukaz.ExecuteNonQuery();
                }
            }
            Nalozi();
        }

        private void Nalozi()
        {
            listBox1.Items.Clear();

            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open();
                var ukaz = connection.CreateCommand();
                ukaz.CommandText = "SELECT id, ime FROM uporabnik";

                using (var reader = ukaz.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        var uporabnik = new KeyValuePair<int, string>(reader.GetInt32(0), reader.GetString(1));
                        listBox1.Items.Add(uporabnik);
                    }
                }
            }
        }

        private void Dodaj_Click(object sender, EventArgs e)
        {
            this.Hide();
            var DodajUporabnika = new DodajUporabnikaAdmin();
            DodajUporabnika.Show();
        }
    }
}