﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace SeminarskaNalogaIzdelek
{
    public partial class DodajUporabnikaAdmin : Form
    {
        public DodajUporabnikaAdmin()
        {
            InitializeComponent();
        }

        private void Potrdi_Click(object sender, EventArgs e)
        {
            string ime = textBox1.Text.Trim();
            string geslo = textBox2.Text.Trim();

            if (string.IsNullOrWhiteSpace(ime) || string.IsNullOrWhiteSpace(geslo))
            {
                MessageBox.Show("Vnesi ime ali geslo ali oboje.");
                return;
            }

            string hash = hashGeslo(geslo);

            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open();
                var ukaz = connection.CreateCommand();
                ukaz.CommandText = "INSERT INTO uporabnik (ime, geslo) VALUES (@ime, @geslo)";
                ukaz.Parameters.AddWithValue("@ime", ime);
                ukaz.Parameters.AddWithValue("@geslo", hash);
                ukaz.ExecuteNonQuery();

                MessageBox.Show("uporabnik z imenom " + ime + " je dodan");
            }

        }

        private string hashGeslo(string geslo)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(geslo));
                StringBuilder builder = new StringBuilder();
                foreach (var b in bytes)
                    builder.Append(b.ToString("x2"));
                return builder.ToString();
            }
        }

        private void Nazaj_Click(object sender, EventArgs e)
        {
            this.Hide();
            var Admin = new UporabnikAdmin();
            Admin.Show();
        }
    }
}
