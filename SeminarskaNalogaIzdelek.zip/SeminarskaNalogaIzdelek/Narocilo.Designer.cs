﻿namespace SeminarskaNalogaIzdelek
{
    partial class Narocilo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            listBox1 = new ListBox();
            listBox2 = new ListBox();
            listBox3 = new ListBox();
            Nazaj = new Button();
            Potrdi = new Button();
            IzbrisiArtikel = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Controls.Add(label2, 0, 3);
            tableLayoutPanel1.Controls.Add(label3, 0, 1);
            tableLayoutPanel1.Controls.Add(label4, 0, 2);
            tableLayoutPanel1.Controls.Add(listBox1, 1, 1);
            tableLayoutPanel1.Controls.Add(listBox2, 1, 2);
            tableLayoutPanel1.Controls.Add(listBox3, 1, 3);
            tableLayoutPanel1.Controls.Add(Nazaj, 0, 5);
            tableLayoutPanel1.Controls.Add(Potrdi, 1, 5);
            tableLayoutPanel1.Controls.Add(IzbrisiArtikel, 1, 4);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 6;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 51.1627922F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 48.8372078F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 92F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 37F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 36F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 218F));
            tableLayoutPanel1.Size = new Size(800, 450);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(label1, 2);
            label1.Location = new Point(3, 9);
            label1.Name = "label1";
            label1.Size = new Size(794, 15);
            label1.TabIndex = 0;
            label1.Text = "Tukaj je celotno tvoje naročilo";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            label2.Location = new Point(3, 169);
            label2.Name = "label2";
            label2.Size = new Size(394, 15);
            label2.TabIndex = 3;
            label2.Text = "Skupaj:";
            label2.TextAlign = ContentAlignment.TopRight;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Right;
            label3.Location = new Point(212, 34);
            label3.Name = "label3";
            label3.Size = new Size(185, 32);
            label3.TabIndex = 4;
            label3.Text = "Naročil si iz naslednje restavracije:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Dock = DockStyle.Right;
            label4.Location = new Point(288, 66);
            label4.Name = "label4";
            label4.Size = new Size(109, 92);
            label4.TabIndex = 5;
            label4.Text = "Spisek vseh naročil:";
            // 
            // listBox1
            // 
            listBox1.Dock = DockStyle.Fill;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(403, 37);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(394, 26);
            listBox1.TabIndex = 6;
            // 
            // listBox2
            // 
            listBox2.Dock = DockStyle.Fill;
            listBox2.FormattingEnabled = true;
            listBox2.ItemHeight = 15;
            listBox2.Location = new Point(403, 69);
            listBox2.Name = "listBox2";
            listBox2.Size = new Size(394, 86);
            listBox2.TabIndex = 7;
            // 
            // listBox3
            // 
            listBox3.Dock = DockStyle.Fill;
            listBox3.FormattingEnabled = true;
            listBox3.ItemHeight = 15;
            listBox3.Location = new Point(403, 161);
            listBox3.Name = "listBox3";
            listBox3.Size = new Size(394, 31);
            listBox3.TabIndex = 8;
            // 
            // Nazaj
            // 
            Nazaj.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            Nazaj.Location = new Point(3, 424);
            Nazaj.Name = "Nazaj";
            Nazaj.Size = new Size(75, 23);
            Nazaj.TabIndex = 2;
            Nazaj.Text = "Nazaj";
            Nazaj.UseVisualStyleBackColor = true;
            Nazaj.Click += Nazaj_Click;
            // 
            // Potrdi
            // 
            Potrdi.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            Potrdi.Location = new Point(722, 424);
            Potrdi.Name = "Potrdi";
            Potrdi.Size = new Size(75, 23);
            Potrdi.TabIndex = 1;
            Potrdi.Text = "Potrdi";
            Potrdi.UseVisualStyleBackColor = true;
            Potrdi.Click += Potrdi_Click;
            // 
            // IzbrisiArtikel
            // 
            IzbrisiArtikel.Location = new Point(403, 198);
            IzbrisiArtikel.Name = "IzbrisiArtikel";
            IzbrisiArtikel.Size = new Size(104, 23);
            IzbrisiArtikel.TabIndex = 9;
            IzbrisiArtikel.Text = "Odstrani artikel";
            IzbrisiArtikel.UseVisualStyleBackColor = true;
            IzbrisiArtikel.Click += IzbrisiArtikel_Click;
            // 
            // Narocilo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tableLayoutPanel1);
            Name = "Narocilo";
            Text = "Narocilo";
            Load += Narocilo_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private Button Potrdi;
        private Button Nazaj;
        private Label label2;
        private Label label3;
        private Label label4;
        private ListBox listBox1;
        private ListBox listBox2;
        private ListBox listBox3;
        private Button IzbrisiArtikel;
    }
}