﻿using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SeminarskaNalogaIzdelek
{
    public partial class Narocilo : Form
    {
        public Narocilo()
        {
            InitializeComponent();
        }

        private void Nazaj_Click(object sender, EventArgs e)
        {
            this.Hide();
            var GlavniMeni = new GlavniMeni();
            GlavniMeni.Show();
        }

        private void Narocilo_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            double skupaj = 0.0;

            HashSet<string> dodaneRestavracije = new HashSet<string>();

            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open();
                var ukaz = connection.CreateCommand();
                ukaz.CommandText = "SELECT restavracija, jed, cena FROM naročilo";

                using (var reader = ukaz.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string restavracija = reader.GetString(0);
                        string jed = reader.GetString(1);
                        double cena = reader.GetDouble(2);

                        if (!dodaneRestavracije.Contains(restavracija))
                        {
                            listBox1.Items.Add(restavracija);
                            dodaneRestavracije.Add(restavracija);
                        }

                        listBox2.Items.Add(jed + " " + cena);
                        skupaj += cena;
                    }
                }
            }
            listBox3.Items.Add(skupaj + " eur");
        }

        private void IzbrisiArtikel_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedIndex == -1)
            {
                MessageBox.Show("Prosim, da izbereš artikel katerega hočeš izbrisati");
                return;
            }

            string artikel = listBox2.SelectedItem.ToString();
            string[] deli = artikel.Split(' ');
            if (deli.Length < 2)
            {
                return;
            }

            string CenaNiz = deli[^1];
            string jed = string.Join(" ", deli.Take(deli.Length - 1));

            if (!double.TryParse(CenaNiz, out double cena))
            {
                MessageBox.Show("Napaka pri razčlenjevanju cene.");
                return;
            }

            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open();
                var ukaz = connection.CreateCommand();
                ukaz.CommandText = "DELETE FROM naročilo WHERE jed = @jed";
                ukaz.Parameters.AddWithValue("@jed", jed);
                ukaz.ExecuteNonQuery();
            }
            Nalozi();
        }

        private void Potrdi_Click(object sender, EventArgs e)
        {
            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open();
                var ukaz = connection.CreateCommand();
                ukaz.CommandText = "SELECT restavracija, jed, cena FROM naročilo";

                using (var reader = ukaz.ExecuteReader())
                {

                    while (reader.Read())
                    {

                        string restavracija = reader.GetString(0);
                        string jed = reader.GetString(1);
                        double cena = reader.GetDouble(2);
                        string datum = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                        var UkazVnesi = connection.CreateCommand();
                        UkazVnesi.CommandText = "INSERT INTO arhiv (restavracija, jed, cena, datum) VALUES (@restavracija, @jed, @cena, @datum)";
                        UkazVnesi.Parameters.AddWithValue("@restavracija", restavracija);
                        UkazVnesi.Parameters.AddWithValue("@jed", jed);
                        UkazVnesi.Parameters.AddWithValue("@cena", cena);
                        UkazVnesi.Parameters.AddWithValue("@datum", datum);


                        UkazVnesi.ExecuteNonQuery();
                    }


                    var UkazIzbrisi = connection.CreateCommand();
                    UkazIzbrisi.CommandText = "DELETE FROM naročilo";
                    UkazIzbrisi.ExecuteNonQuery();
                }
                MessageBox.Show("Hvala za vaše naročilo");

                listBox1.Items.Clear();
                listBox2.Items.Clear();
                listBox3.Items.Clear();
            }
        }

        private void Nalozi()
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();

            double skupaj = 0.0;
            HashSet<string> dodaneRestavracije = new HashSet<string>();

            using (var connection = new SqliteConnection($"Data Source={AppDomain.CurrentDomain.BaseDirectory}baza.db"))
            {
                connection.Open();
                var ukaz = connection.CreateCommand();
                ukaz.CommandText = "SELECT restavracija, jed, cena FROM naročilo";

                using (var reader = ukaz.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string restavracija = reader.GetString(0);
                        string jed = reader.GetString(1);
                        double cena = reader.GetDouble(2);

                        if (!dodaneRestavracije.Contains(restavracija))
                        {
                            listBox1.Items.Add(restavracija);
                            dodaneRestavracije.Add(restavracija);
                        }

                        listBox2.Items.Add(jed + " " + cena);
                        skupaj += cena;
                    }
                }

                listBox3.Items.Add(skupaj + " eur");

            }
        }
    }
}