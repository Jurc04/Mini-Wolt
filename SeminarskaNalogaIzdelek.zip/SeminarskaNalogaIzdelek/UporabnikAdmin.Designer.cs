﻿namespace SeminarskaNalogaIzdelek
{
    partial class UporabnikAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel1 = new TableLayoutPanel();
            label1 = new Label();
            label2 = new Label();
            listBox1 = new ListBox();
            Izbrisi = new Button();
            Uredi = new Button();
            Dodaj = new Button();
            Nazaj = new Button();
            tableLayoutPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 3;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 49.5F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50.5F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 467F));
            tableLayoutPanel1.Controls.Add(label1, 0, 0);
            tableLayoutPanel1.Controls.Add(label2, 0, 1);
            tableLayoutPanel1.Controls.Add(listBox1, 0, 2);
            tableLayoutPanel1.Controls.Add(Izbrisi, 1, 3);
            tableLayoutPanel1.Controls.Add(Uredi, 0, 3);
            tableLayoutPanel1.Controls.Add(Nazaj, 0, 4);
            tableLayoutPanel1.Controls.Add(Dodaj, 2, 3);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 5;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 43.75F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 56.25F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 204F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 164F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(800, 450);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(label1, 3);
            label1.Location = new Point(3, 1);
            label1.Name = "label1";
            label1.Size = new Size(794, 15);
            label1.TabIndex = 0;
            label1.Text = "Tukaj lahko upravljaš z uporabniki, izbrišeš...";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            label2.AutoSize = true;
            tableLayoutPanel1.SetColumnSpan(label2, 3);
            label2.Location = new Point(3, 22);
            label2.Name = "label2";
            label2.Size = new Size(794, 15);
            label2.TabIndex = 1;
            label2.Text = "Seznam uporabnikov:";
            label2.TextAlign = ContentAlignment.TopCenter;
            // 
            // listBox1
            // 
            tableLayoutPanel1.SetColumnSpan(listBox1, 3);
            listBox1.Dock = DockStyle.Fill;
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 15;
            listBox1.Location = new Point(3, 44);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(794, 198);
            listBox1.TabIndex = 2;
            // 
            // Izbrisi
            // 
            Izbrisi.Location = new Point(167, 248);
            Izbrisi.Name = "Izbrisi";
            Izbrisi.Size = new Size(75, 23);
            Izbrisi.TabIndex = 3;
            Izbrisi.Text = "Izbrisi";
            Izbrisi.UseVisualStyleBackColor = true;
            Izbrisi.Click += Izbrisi_Click;
            // 
            // Uredi
            // 
            Uredi.Location = new Point(3, 248);
            Uredi.Name = "Uredi";
            Uredi.Size = new Size(75, 23);
            Uredi.TabIndex = 4;
            Uredi.Text = "Uredi";
            Uredi.UseVisualStyleBackColor = true;
            Uredi.Click += Uredi_Click;
            // 
            // Dodaj
            // 
            Dodaj.Location = new Point(335, 248);
            Dodaj.Name = "Dodaj";
            Dodaj.Size = new Size(114, 23);
            Dodaj.TabIndex = 5;
            Dodaj.Text = "Dodaj uporabnika";
            Dodaj.UseVisualStyleBackColor = true;
            Dodaj.Click += Dodaj_Click;
            // 
            // Nazaj
            // 
            Nazaj.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            Nazaj.Location = new Point(3, 424);
            Nazaj.Name = "Nazaj";
            Nazaj.Size = new Size(75, 23);
            Nazaj.TabIndex = 6;
            Nazaj.Text = "Nazaj";
            Nazaj.UseVisualStyleBackColor = true;
            Nazaj.Click += Nazaj_Click;
            // 
            // UporabnikAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tableLayoutPanel1);
            Name = "UporabnikAdmin";
            Text = "UporabnikAdmin";
            Load += UporabnikAdmin_Load;
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private Label label2;
        private ListBox listBox1;
        private Button Izbrisi;
        private Button Uredi;
        private Button Dodaj;
        private Button Nazaj;
    }
}